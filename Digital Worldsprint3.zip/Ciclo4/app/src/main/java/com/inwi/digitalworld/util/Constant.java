package com.inwi.digitalworld.util;

public class Constant {

    public Constant(){
    }

    public static final String PREFERENCE = "MY_PREFERENCE";

    public static final String NAME_TABLE_USER = "user";

    public static final String NAME_DATABASE = "digitalworld_db.db";

}
